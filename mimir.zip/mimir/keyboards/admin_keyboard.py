from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

start_admin_kb = ReplyKeyboardMarkup(keyboard=[
                                    [
                                        KeyboardButton(text='Пользователи'),
                                        KeyboardButton(text='Учебные заведения'),
                                    ], 
                                    [
                                        KeyboardButton(text='Выйти'),
                                    ]
                                ], resize_keyboard=True)

reduct_test = ReplyKeyboardMarkup(keyboard=[
                                    [
                                        KeyboardButton(text='Реалистический'),
                                        KeyboardButton(text='Интеллектуальный'),
                                    ],
                                    [
                                        KeyboardButton(text='Социальный'),
                                        KeyboardButton(text='Конвенциальный'),
                                    ],
                                    [
                                        KeyboardButton(text='Предприимчивый'),
                                        KeyboardButton(text='Артистический'),
                                    ],
                                ], resize_keyboard=True)

reductadminuser = InlineKeyboardMarkup(row_width=2,
                               inline_keyboard=[
                                    [
                                        InlineKeyboardButton(text='Редактировать', callback_data='Редактировать'),
                                        InlineKeyboardButton(text='Удалить', callback_data='Удалить'),
                                    ],
                                    [
                                        InlineKeyboardButton(text='Выход', callback_data='Выход')
                                    ]
                               ])

reductadmincolleds = InlineKeyboardMarkup(row_width=2,
                               inline_keyboard=[
                                    [
                                        InlineKeyboardButton(text='Добавить', callback_data='Добавить'),
                                        InlineKeyboardButton(text='Найти', callback_data='Найти'),
                                    ],
                                    [
                                        InlineKeyboardButton(text='Выход', callback_data='Выход')
                                    ]
                               ])

reductscolleges_kb = ReplyKeyboardMarkup(keyboard=[
                                    [
                                        KeyboardButton(text='Наименование'),
                                        KeyboardButton(text='Специальность'),
                                    ], 
                                    [
                                        KeyboardButton(text='Ограничение'),
                                        KeyboardButton(text='Классы'),
                                    ],
                                    [
                                        KeyboardButton(text='Экзамены'),
                                        KeyboardButton(text='Формат обучения'),
                                    ],
                                    [
                                        KeyboardButton(text='Оплата'),
                                        KeyboardButton(text='Тест'),
                                    ],
                                    [
                                        KeyboardButton(text='Закрыть'),
                                    ],
                                    [
                                        KeyboardButton(text='Удалить'),
                                    ]
                                ], resize_keyboard=True)