from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

info_kb = InlineKeyboardMarkup(row_width=2,
                               inline_keyboard=[
                                    [
                                        InlineKeyboardButton(text='Изменить', callback_data='Изменить'),
                                        InlineKeyboardButton(text='Посмотреть', callback_data='Посмотреть'),
                                    ]
                               ])

reducts_kb = ReplyKeyboardMarkup(keyboard=[
                                    [
                                        KeyboardButton(text='ФИО'),
                                        KeyboardButton(text='Возраст'),
                                    ], 
                                    [
                                        KeyboardButton(text='Тест'),
                                        KeyboardButton(text='Здоровье'),
                                    ],
                                    [
                                        KeyboardButton(text='Закрыть'),
                                    ]
                                ], resize_keyboard=True)

forms_kb = ReplyKeyboardMarkup(keyboard=[
                                [
                                    KeyboardButton(text='1'),
                                    KeyboardButton(text='2'),
                                ]
                                ], resize_keyboard=True)