from aiogram.types import Message, CallbackQuery, ReplyKeyboardRemove
from db import UserDataBase, TestDataBase, CollegeDataBase
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher.filters import Text
from start import dp
from src import reads
from keyboards import info_kb, reducts_kb, forms_kb

tests = ['инженер-техник', 'инженер-контролер', 
                    'вязальщик', 'санитарный врач',
                    'повар', 'наборщик',
                    'фотограф', 'зав. магазином',
                    'чертежник', 'дизайнер',
                    'философ', 	'психиатр',
                    'ученый-химик', 'бухгалтер',
                    'редактор научного журнала', 'адвокат',
                    'лингвист', 'переводчик художественной литературы',
                    'педиатр', 'статистик',
                    'организатор воспитательной работы', 'председатель профсоюза',
                    'спортивный врач', 'фельетонист',
                    'нотариус', 'снабженец',
                    'перфоратор', 'карикатурист',
                    'политический деятель', 'писатель',
                    'садовник', 'метеоролог',
                    'водитель', 'медсестра',
                    'инженер-электрик', 'секретарь-машинистка',
                    'маляр', 'художник по металлу',
                    'биолог', 'главный врач',
                    'телеоператор', 'режиссер']

class FSMUserRegist(StatesGroup):
    reduct = State()
    fio = State()
    age = State()
    health = State()

class FSMTest(StatesGroup):
    forms_1 = State()
    forms_2 = State()
    forms_3 = State()
    forms_4 = State()
    forms_5 = State()
    forms_6 = State()
    forms_7 = State()
    forms_8 = State()
    forms_9 = State()
    forms_10 = State()
    forms_11 = State()
    forms_12 = State()
    forms_13 = State()
    forms_14 = State()
    forms_15 = State()
    forms_16 = State()
    forms_17 = State()
    forms_18 = State()
    forms_19 = State()
    forms_20 = State()
    forms_21 = State()

@dp.message_handler(commands=['start'])
async def command_start(message: Message):
    stats = await UserDataBase().set_users(user_id=message.from_user.id, user_nick=message.from_user.username)
    if stats:
        await message.answer(reads()['users']['start_true'].format(nick=message.from_user.username))
    elif stats is None:
        await message.answer(reads()['users']['start_false'])
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(commands=['info_regulars'])
async def command_info_regulars(message: Message):
    stats = await UserDataBase().find_users(message.from_user.id)
    if stats:
        await message.answer(reads()['users']['info_regulars_true'].format(id=stats['_id'], 
                                                                            nick=stats['user_nick'],
                                                                            date=stats['time_regist'].split(' ')[0],
                                                                            time=stats['time_regist'].split(' ')[1],
                                                                            fio=stats['fio'],
                                                                            age=stats['age'],
                                                                            test=stats['test'], 
                                                                            health=stats['health']), reply_markup=info_kb)
    elif stats is None:
        await message.answer(reads()['users']['info_regulars_false'])
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.callback_query_handler(text='Изменить', state=None)
async def redacts_cb(call: CallbackQuery):
    await call.answer('Изменение Персональных данных', cache_time=60)
    await call.message.answer('Вы перешли в изменения Персональных данных!', reply_markup=reducts_kb)
    await FSMUserRegist.reduct.set()

@dp.message_handler(Text(equals=['ФИО', 'Возраст', 'Тест', 'Здоровье', 'Закрыть']), state=FSMUserRegist.reduct)
async def fsm_start(message: Message, state: FSMContext):
    match message.text:
        case 'ФИО':
            await FSMUserRegist.fio.set()
            await message.answer('Укажите ФИО!')
        case 'Возраст':
            await FSMUserRegist.age.set()
            await message.answer('Укажите возраст!')
        case 'Тест':
            await message.answer('Пройдите небольшой профориентационный тест (21 вопрос)!\nИз каждой пары профессий нужно указать одну, предпочитаемую! (используя кнопки)')
            await TestDataBase().set_testusers(user_id=message.from_user.id)
            await message.answer(f'Вопрос 1.\n{tests[0]}\n{tests[1]}', reply_markup=forms_kb)
            await FSMTest.forms_1.set()
        case 'Здоровье':
            await FSMUserRegist.health.set()
            await message.answer('Укажите состояние здоровья!')
        case 'Закрыть':
            await message.answer('Закрытие вкладки изменения Персональных данных!', reply_markup=ReplyKeyboardRemove())
            await state.finish()

@dp.message_handler(state=FSMUserRegist.fio)
async def fsm_fio(message: Message):
    await UserDataBase().get_users(user_id=message.from_user.id, key='fio', value=message.text)
    await message.reply('Данные были обновлены.')
    await FSMUserRegist.reduct.set()

@dp.message_handler(state=FSMUserRegist.age)
async def fsm_age(message: Message):
    await UserDataBase().get_users(user_id=message.from_user.id, key='age', value=message.text)
    await message.reply('Данные были обновлены.')
    await FSMUserRegist.reduct.set()

@dp.message_handler(state=FSMTest.forms_1)
async def fsm_forms_1(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='1', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 2.\n{tests[2]}\n{tests[3]}', reply_markup=forms_kb)
    await FSMTest.forms_2.set()

@dp.message_handler(state=FSMTest.forms_2)
async def fsm_forms_2(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='2', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 3.\n{tests[4]}\n{tests[5]}', reply_markup=forms_kb)
    await FSMTest.forms_3.set()

@dp.message_handler(state=FSMTest.forms_3)
async def fsm_forms_3(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='3', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 4.\n{tests[6]}\n{tests[7]}', reply_markup=forms_kb)
    await FSMTest.forms_4.set()

@dp.message_handler(state=FSMTest.forms_4)
async def fsm_forms_4(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='4', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 5.\n{tests[8]}\n{tests[9]}', reply_markup=forms_kb)
    await FSMTest.forms_5.set()

@dp.message_handler(state=FSMTest.forms_5)
async def fsm_forms_5(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='5', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 6.\n{tests[10]}\n{tests[11]}', reply_markup=forms_kb)
    await FSMTest.forms_6.set()

@dp.message_handler(state=FSMTest.forms_6)
async def fsm_forms_6(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='6', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 7.\n{tests[12]}\n{tests[13]}', reply_markup=forms_kb)
    await FSMTest.forms_7.set()

@dp.message_handler(state=FSMTest.forms_7)
async def fsm_forms_7(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='7', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 8.\n{tests[14]}\n{tests[15]}', reply_markup=forms_kb)
    await FSMTest.forms_8.set()

@dp.message_handler(state=FSMTest.forms_8)
async def fsm_forms_8(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='8', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 9.\n{tests[16]}\n{tests[17]}', reply_markup=forms_kb)
    await FSMTest.forms_9.set()

@dp.message_handler(state=FSMTest.forms_9)
async def fsm_forms_9(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='9', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 10.\n{tests[18]}\n{tests[19]}', reply_markup=forms_kb)
    await FSMTest.forms_10.set()

@dp.message_handler(state=FSMTest.forms_10)
async def fsm_forms_10(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='10', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 11.\n{tests[20]}\n{tests[21]}', reply_markup=forms_kb)
    await FSMTest.forms_11.set()

@dp.message_handler(state=FSMTest.forms_11)
async def fsm_forms_11(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='11', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 12.\n{tests[22]}\n{tests[23]}', reply_markup=forms_kb)
    await FSMTest.forms_12.set()

@dp.message_handler(state=FSMTest.forms_12)
async def fsm_forms_12(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='12', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 13.\n{tests[24]}\n{tests[25]}', reply_markup=forms_kb)
    await FSMTest.forms_13.set()

@dp.message_handler(state=FSMTest.forms_13)
async def fsm_forms_13(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='13', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 14.\n{tests[26]}\n{tests[27]}', reply_markup=forms_kb)
    await FSMTest.forms_14.set()
    
@dp.message_handler(state=FSMTest.forms_14)
async def fsm_forms_14(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='14', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 15.\n{tests[28]}\n{tests[29]}', reply_markup=forms_kb)
    await FSMTest.forms_15.set()

@dp.message_handler(state=FSMTest.forms_15)
async def fsm_forms_15(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='15', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 16.\n{tests[30]}\n{tests[31]}', reply_markup=forms_kb)
    await FSMTest.forms_16.set()

@dp.message_handler(state=FSMTest.forms_16)
async def fsm_forms_16(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='16', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 17.\n{tests[32]}\n{tests[33]}', reply_markup=forms_kb)
    await FSMTest.forms_17.set()

@dp.message_handler(state=FSMTest.forms_17)
async def fsm_forms_17(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='17', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 18.\n{tests[34]}\n{tests[35]}', reply_markup=forms_kb)
    await FSMTest.forms_18.set()

@dp.message_handler(state=FSMTest.forms_18)
async def fsm_forms_18(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='18', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 19.\n{tests[36]}\n{tests[37]}', reply_markup=forms_kb)
    await FSMTest.forms_19.set()

@dp.message_handler(state=FSMTest.forms_19)
async def fsm_forms_19(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='19', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 20.\n{tests[38]}\n{tests[39]}', reply_markup=forms_kb)
    await FSMTest.forms_20.set()

@dp.message_handler(state=FSMTest.forms_20)
async def fsm_forms_20(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='20', value=message.text)
    await message.reply('Данные были обновлены.')
    await message.answer(f'Вопрос 21.\n{tests[40]}\n{tests[41]}', reply_markup=forms_kb)
    await FSMTest.forms_21.set()

@dp.message_handler(state=FSMTest.forms_21)
async def fsm_forms_21(message: Message):
    await TestDataBase().get_testusers(user_id=message.from_user.id, key='21', value=message.text)
    await message.reply('Данные были обновлены.', reply_markup=reducts_kb)
    await message.answer('Тест закончен, подводится итог!')
    stats = await TestDataBase().find_testusers(user_id=message.from_user.id)
    if stats['1'] == '1' and stats['2'] == '1' and stats['3'] == '1' and stats['4'] == '1' and stats['5'] == '1' and stats['16'] == '1' and stats['17'] == '1' and stats['18'] == '1' and stats['19'] == '1' and stats['21'] == '1':
        await UserDataBase().get_users(user_id=message.from_user.id, key='test', value='Реалистический тип (механик, электрик, инженер, фермер, зоотехник, агроном, садовод, автослесарь, шофер и т.д.)')
        await message.answer('Ваш тип установлен в Персональных данных!')

    elif stats['1'] == '2' and stats['6'] == '1' and stats['7'] == '1' and stats['8'] == '1' and stats['9'] == '1' and stats['16'] == '2' and stats['20'] == '1':
        await UserDataBase().get_users(user_id=message.from_user.id, key='test', value='Интеллектуальный тип (физик, астроном, ботаник, программист и др.)')
        await message.answer('Ваш тип установлен в Персональных данных!')

    elif stats['2'] == '2' and stats['6'] == '2' and stats['10'] == '1' and stats['11'] == '1' and stats['12'] == '1' and stats['17'] == '2':
        await UserDataBase().get_users(user_id=message.from_user.id, key='test', value='Социальный тип (врач, педагог, психолог и т.п.)')
        await message.answer('Ваш тип установлен в Персональных данных!')

    elif stats['3'] == '2' and stats['7'] == '2' and stats['10'] == '2' and stats['13'] == '1' and stats['14'] == '1' and stats['18'] == '2':
        await UserDataBase().get_users(user_id=message.from_user.id, key='test', value='Конвенциальный тип (бухгалтер, финансист, экономист, канцелярский служащий и др)')
        await message.answer('Ваш тип установлен в Персональных данных!')

    elif stats['4'] == '2' and stats['8'] == '2' and stats['11'] == '2' and stats['13'] == '2' and stats['15'] == '1':
        await UserDataBase().get_users(user_id=message.from_user.id, key='test', value='Предприимчивый тип (бизнесмен, маркетолог, менеджер, директор, заведующий, журналист, репортер, дипломат, юрист, политик и т.д.)')
        await message.answer('Ваш тип установлен в Персональных данных!')

    elif stats['5'] == '2' and stats['9'] == '2' and stats['12'] == '2' and stats['14'] == '2' and stats['15'] == '2' and stats['19'] == '2' and stats['21'] == '2':
        await UserDataBase().get_users(user_id=message.from_user.id, key='test', value='Артистический тип (музыкант, художник, фотограф, актер, режиссер, дизайнер и т.д.)')
        await message.answer('Ваш тип установлен в Персональных данных!')

    else:
        await UserDataBase().get_users(user_id=message.from_user.id, key='test', value='Не указано')
        await message.answer('К сожалению, нам не удалось определить вас в какую-то группу. Попробуйте пройти тест ещё раз!')
    await FSMUserRegist.reduct.set()

@dp.message_handler(state=FSMUserRegist.health)
async def fsm_health(message: Message):
    await UserDataBase().get_users(user_id=message.from_user.id, key='health', value=message.text)
    await message.reply('Данные были обновлены.')
    await FSMUserRegist.reduct.set()

@dp.callback_query_handler(text='Посмотреть', state=None)
async def redacts_cb(call: CallbackQuery):
    await call.answer('Просмотр подходящих учебных заведений', cache_time=60)
    await call.message.answer('Вы перешли в Просмотр учебных заведений!')
    test = await UserDataBase().find_users(user_id=call.message.chat.id)
    match test['test']:
        case 'Реалистический тип (механик, электрик, инженер, фермер, зоотехник, агроном, садовод, автослесарь, шофер и т.д.)':
            results = await CollegeDataBase().find_test_colleges(key='description_type', value='Реалистический тип (механик, электрик, инженер, фермер, зоотехник, агроном, садовод, автослесарь, шофер и т.д.)')
            for result in results:
                await call.message.answer('Наименование учебного заведения: {}\nСпециальность: {}\nОграниченные возможности: {}\nНа базе классов: {}\nНеобходимые пороги для сдачи экзаменов: {}\nФормат обучения: {}\nПлатная/Бесплатная: {}'.format(result['college_name'], result['college_speciality'], result['college_health'], result['klass'], result['results'], result['format'], result['pay']))

        case 'Интеллектуальный тип (физик, астроном, ботаник, программист и др.)':
            results = await CollegeDataBase().find_test_colleges(key='description_type', value='Интеллектуальный тип (физик, астроном, ботаник, программист и др.)')
            for result in results:
                await call.message.answer('Наименование учебного заведения: {}\nСпециальность: {}\nОграниченные возможности: {}\nНа базе классов: {}\nНеобходимые пороги для сдачи экзаменов: {}\nФормат обучения: {}\nПлатная/Бесплатная: {}'.format(result['college_name'], result['college_speciality'], result['college_health'], result['klass'], result['results'], result['format'], result['pay']))

        case 'Социальный тип (врач, педагог, психолог и т.п.)':
            results = await CollegeDataBase().find_test_colleges(key='description_type', value='Социальный тип (врач, педагог, психолог и т.п.)')
            for result in results:
                await call.message.answer('Наименование учебного заведения: {}\nСпециальность: {}\nОграниченные возможности: {}\nНа базе классов: {}\nНеобходимые пороги для сдачи экзаменов: {}\nФормат обучения: {}\nПлатная/Бесплатная: {}'.format(result['college_name'], result['college_speciality'], result['college_health'], result['klass'], result['results'], result['format'], result['pay']))

        case 'Конвенциальный тип (бухгалтер, финансист, экономист, канцелярский служащий и др)':
            results = await CollegeDataBase().find_test_colleges(key='description_type', value='Конвенциальный тип (бухгалтер, финансист, экономист, канцелярский служащий и др)')
            for result in results:
                await call.message.answer('Наименование учебного заведения: {}\nСпециальность: {}\nОграниченные возможности: {}\nНа базе классов: {}\nНеобходимые пороги для сдачи экзаменов: {}\nФормат обучения: {}\nПлатная/Бесплатная: {}'.format(result['college_name'], result['college_speciality'], result['college_health'], result['klass'], result['results'], result['format'], result['pay']))

        case 'Предприимчивый тип (бизнесмен, маркетолог, менеджер, директор, заведующий, журналист, репортер, дипломат, юрист, политик и т.д.)':
            results = await CollegeDataBase().find_test_colleges(key='description_type', value='Предприимчивый тип (бизнесмен, маркетолог, менеджер, директор, заведующий, журналист, репортер, дипломат, юрист, политик и т.д.)')
            for result in results:
                await call.message.answer('Наименование учебного заведения: {}\nСпециальность: {}\nОграниченные возможности: {}\nНа базе классов: {}\nНеобходимые пороги для сдачи экзаменов: {}\nФормат обучения: {}\nПлатная/Бесплатная: {}'.format(result['college_name'], result['college_speciality'], result['college_health'], result['klass'], result['results'], result['format'], result['pay']))

        case 'Артистический тип (музыкант, художник, фотограф, актер, режиссер, дизайнер и т.д.)':
            results = await CollegeDataBase().find_test_colleges(key='description_type', value='Артистический тип (музыкант, художник, фотограф, актер, режиссер, дизайнер и т.д.)')
            for result in results:
                await call.message.answer('Наименование учебного заведения: {}\nСпециальность: {}\nОграниченные возможности: {}\nНа базе классов: {}\nНеобходимые пороги для сдачи экзаменов: {}\nФормат обучения: {}\nПлатная/Бесплатная: {}'.format(result['college_name'], result['college_speciality'], result['college_health'], result['klass'], result['results'], result['format'], result['pay']))

        case 'Не указано':
            await call.message.answer('Пройдите тест, чтобы узнать, какие специальности вам подходят!')