from aiogram.types import Message, CallbackQuery, ReplyKeyboardRemove
from db import AdminDataBase, CollegeDataBase, UserDataBase
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher.filters import Text
from start import dp
from src import reads, random_id
from keyboards import *

class FSMAuthAdmin(StatesGroup):
    admin_id = State()

class FSMAdiminState(StatesGroup):
    colleges_id = State()
    reduct = State()
    sprays = State()
    name = State()
    speciality = State()
    ogr = State()
    klass = State()
    exem = State()
    formats = State()
    pay = State()
    description = State()

class FSMAdiminState1(StatesGroup):
    users = State()
    reduct = State()
    description_fio = State()
    description_age = State()
    description_test = State()
    description_health = State()



@dp.message_handler(commands=['admin_auth'])
async def command_admin_auth(message: Message):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        await message.answer('Пришлите его ID!')
        await FSMAuthAdmin.admin_id.set()
    elif stats is None:
        await message.answer('У вас нет прав Администратора!')
    else:
        await message.answer(reads()['errors']['global_error'])


@dp.message_handler(state=FSMAuthAdmin.admin_id)
async def command_admin_auth(message: Message, state: FSMContext):
    admins_stat = await AdminDataBase().set_admins(admin_id=int(message.text))
    await message.answer(admins_stat)
    await state.finish()

@dp.message_handler(commands=['start_admin'])
async def command_start(message: Message):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        await message.answer('Вы вошли в систему под правами Администратор!', reply_markup=start_admin_kb)
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(Text(equals=['Пользователи', 'Учебные заведения', 'Выйти']))
async def fsm_start_et(message: Message):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        match message.text:
            case 'Пользователи':
                await FSMAdiminState1.users.set()
                await message.answer('Укажите ID пользователя для просмотра!')

            case 'Учебные заведения':
                await FSMAdiminState.colleges_id.set()
                await message.answer('Вы перешли в раздел учебных заведений!', reply_markup=reductadmincolleds)

            case 'Выйти':
                await message.answer('Закрытие вкладки администрирования!', reply_markup=ReplyKeyboardRemove())
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.callback_query_handler(text='Добавить', state=FSMAdiminState.colleges_id)
async def redacts_dobl(call: CallbackQuery, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=call.message.chat.id)
    if stats:
        colleges_id = random_id()
        await CollegeDataBase().set_colleges(college_id=colleges_id, college_name='В заполнении', description_type='В заполнении')
        await state.update_data(colleges_id=int(colleges_id))
        await call.answer('Добавление учебного заведения', cache_time=60)
        await call.message.answer('Переход в раздел добавления учебного заведения', reply_markup=reductscolleges_kb)
        await FSMAdiminState.reduct.set()
    elif stats is None:
        await call.message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await call.message.answer(reads()['errors']['global_error'])

@dp.message_handler(Text(equals=['Наименование', 'Специальность', 'Ограничение', 'Классы', 'Экзамены', 'Формат обучения', 'Оплата', 'Тест', 'Закрыть', 'Удалить']), state=FSMAdiminState.reduct)
async def fsm_stert_reduct(message: Message, state: FSMContext):
    colle_id = await state.get_data()
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        match message.text:
            case 'Наименование':
                await FSMAdiminState.name.set()
                await message.answer('Укажите наименование учебного заведения!')

            case 'Специальность':
                await FSMAdiminState.speciality.set()
                await message.answer('Укажите специальность!')

            case 'Ограничение':
                await FSMAdiminState.ogr.set()
                await message.answer('Укажите ограничение возможности!')

            case 'Классы':
                await FSMAdiminState.klass.set()
                await message.answer('Укажите на базе какого класса!')

            case 'Экзамены':
                await FSMAdiminState.exem.set()
                await message.answer('Укажите необходимый порог для сдачи экзаменов!')

            case 'Формат обучения':
                await FSMAdiminState.formats.set()
                await message.answer('Укажите формат обучения!')

            case 'Оплата':
                await FSMAdiminState.pay.set()
                await message.answer('Укажите состояние оплаты!')
                
            case 'Тест':
                await FSMAdiminState.description.set()
                await message.answer('Укажите тест от профориентации!', reply_markup=reduct_test)

            case 'Удалить':
                await message.answer('Удаление ранних данных об учебном заведении.', reply_markup=ReplyKeyboardRemove())
                await message.answer('Закрытие вкладки добавления данных учебного заведения!', reply_markup=reductadmincolleds)
                await CollegeDataBase().del_colleges(colleges_id=colle_id['colleges_id'])

            case 'Закрыть':
                await message.answer('Закрытие вкладки', reply_markup=ReplyKeyboardRemove())
                await message.answer('Закрытие вкладки добавления данных учебного заведения!', reply_markup=reductadmincolleds)
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState.name)
async def fsm_name(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        colleges_id = await state.get_data()
        print(colleges_id)
        await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='college_name', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState.speciality)
async def fsm_speciality(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        colleges_id = await state.get_data()
        await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='college_speciality', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState.ogr)
async def fsm_ogr(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        colleges_id = await state.get_data()
        await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='college_health', value=message.text)
        await message.reply('Данные были обновлены.', reply_markup=reductscolleges_kb)
        await FSMAdiminState.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState.klass)
async def fsm_klass(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        colleges_id = await state.get_data()
        await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='klass', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState.exem)
async def fsm_exem(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        colleges_id = await state.get_data()
        await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='results', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState.formats)
async def fsm_formats(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        colleges_id = await state.get_data()
        await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='format', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState.pay)
async def fsm_pay(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        colleges_id = await state.get_data()
        await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='pay', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(Text(equals=['Реалистический', 'Интеллектуальный', 'Социальный', 'Конвенциальный', 'Предприимчивый', 'Артистический']), state=FSMAdiminState.description)
async def fsm_description(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        colleges_id = await state.get_data()
        match message.text:
            case 'Реалистический':
                await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='description_type', value='Реалистический тип (механик, электрик, инженер, фермер, зоотехник, агроном, садовод, автослесарь, шофер и т.д.)')
                await message.reply('Данные были обновлены.', reply_markup=reductscolleges_kb)

            case 'Интеллектуальный':
                await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='description_type', value='Интеллектуальный тип (физик, астроном, ботаник, программист и др.)')
                await message.reply('Данные были обновлены.', reply_markup=reductscolleges_kb)

            case 'Социальный':
                await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='description_type', value='Социальный тип (врач, педагог, психолог и т.п.)')
                await message.reply('Данные были обновлены.', reply_markup=reductscolleges_kb)

            case 'Конвенциальный':
                await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='description_type', value='Конвенциальный тип (бухгалтер, финансист, экономист, канцелярский служащий и др)')
                await message.reply('Данные были обновлены.', reply_markup=reductscolleges_kb)

            case 'Предприимчивый':
                await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='description_type', value='Предприимчивый тип (бизнесмен, маркетолог, менеджер, директор, заведующий, журналист, репортер, дипломат, юрист, политик и т.д.)')
                await message.reply('Данные были обновлены.', reply_markup=reductscolleges_kb)

            case 'Артистический':
                await CollegeDataBase().get_colleges(college_id=colleges_id['colleges_id'], key='description_type', value='Артистический тип (музыкант, художник, фотограф, актер, режиссер, дизайнер и т.д.)')
                await message.reply('Данные были обновлены.', reply_markup=reductscolleges_kb)

        await FSMAdiminState.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.callback_query_handler(text='Найти', state=FSMAdiminState.reduct)
async def sert_cb(call: CallbackQuery):
    stats = await AdminDataBase().find_admins(admin_id=call.message.chat.id)
    if stats:
        await call.answer('Поиск учебного заведения', cache_time=60)
        await call.message.answer('Переход в раздел поиска учебного заведения', reply_markup=ReplyKeyboardRemove())
        await call.message.answer('Введите наименование учебного заведения!')
        await FSMAdiminState.sprays.set()
    elif stats is None:
        await call.message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await call.message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState.sprays)
async def fsm_sprays(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        name_colleges = message.text
        try:
            results = await CollegeDataBase().find_test_colleges(key='college_name', value=name_colleges)
            if results[0]['college_name'] is not None:
                for result in results:
                    await message.answer('Наименование учебного заведения: {}\nСпециальность: {}\nОграниченные возможности: {}\nНа базе классов: {}\nНеобходимые пороги для сдачи экзаменов: {}\nФормат обучения: {}\nПлатная/Бесплатная: {}'.format(result['college_name'], result['college_speciality'], result['college_health'], result['klass'], result['results'], result['format'], result['pay']), reply_markup=start_admin_kb)
            else:
                await message.answer('К сожалению, но нет такого учебного заведения в базе!', reply_markup=start_admin_kb)
        except:
            await message.answer('К сожалению, но нет такого учебного заведения в базе!', reply_markup=start_admin_kb)
        finally:
            await state.finish()

    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState1.users)
async def fsm_users_id(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        user_find = await UserDataBase().find_users(user_id=int(message.text))
        if user_find:
            await state.update_data(user_id=int(message.text))
            await message.answer(reads()['admins']['info_regulars_true'].format(id=user_find['_id'], 
                                                                                nick=user_find['user_nick'],
                                                                                date=user_find['time_regist'].split(' ')[0],
                                                                                time=user_find['time_regist'].split(' ')[1],
                                                                                fio=user_find['fio'],
                                                                                age=user_find['age'],
                                                                                test=user_find['test'], 
                                                                                health=user_find['health']), reply_markup=reductadminuser)
        elif user_find is None:
            await message.answer(reads()['admins']['info_regulars_false'])
            await state.finish()
        else:
            await message.answer(reads()['errors']['global_error'])
            await state.finish()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.callback_query_handler(text='Редактировать', state=FSMAdiminState1.users)
async def redacts_reducts(call: CallbackQuery):
    stats = await AdminDataBase().find_admins(admin_id=call.message.chat.id)
    if stats:
        await call.answer('Редактирование данных пользователя', cache_time=60)
        await call.message.answer('Вы перешли в редактирование данных!', reply_markup=reducts_kb)
        await FSMAdiminState1.reduct.set()
    elif stats is None:
        await call.message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await call.message.answer(reads()['errors']['global_error'])

@dp.message_handler(Text(equals=['ФИО', 'Возраст', 'Тест', 'Здоровье', 'Закрыть']), state=FSMAdiminState1.reduct)
async def fsm_start(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        match message.text:
            case 'ФИО':
                await FSMAdiminState1.description_fio.set()
                await message.answer('Укажите ФИО!')

            case 'Возраст':
                await FSMAdiminState1.description_age.set()
                await message.answer('Укажите возраст!')

            case 'Тест':
                await FSMAdiminState1.description_test.set()
                await message.answer('Укажите какой тип присвоить пользователю!\nРеалистический тип (механик, электрик, инженер, фермер, зоотехник, агроном, садовод, автослесарь, шофер и т.д.)\nИнтеллектуальный тип (физик, астроном, ботаник, программист и др.)\nСоциальный тип (врач, педагог, психолог и т.п.)\nКонвенциальный тип (бухгалтер, финансист, экономист, канцелярский служащий и др)\nПредприимчивый тип (бизнесмен, маркетолог, менеджер, директор, заведующий, журналист, репортер, дипломат, юрист, политик и т.д.)\nАртистический тип (музыкант, художник, фотограф, актер, режиссер, дизайнер и т.д.)', reply_markup=reduct_test)

            case 'Здоровье':
                await FSMAdiminState1.description_health.set()
                await message.answer('Укажите состояние здоровья!')

            case 'Закрыть':
                await message.answer('Закрытие вкладки изменения данных!', reply_markup=ReplyKeyboardRemove())
                user_id = await state.get_data()
                print(user_id)
                user_find = await UserDataBase().find_users(user_id=user_id['user_id'])
                await message.answer(reads()['admins']['info_regulars_true'].format(id=user_find['_id'], 
                                                                                nick=user_find['user_nick'],
                                                                                date=user_find['time_regist'].split(' ')[0],
                                                                                time=user_find['time_regist'].split(' ')[1],
                                                                                fio=user_find['fio'],
                                                                                age=user_find['age'],
                                                                                test=user_find['test'], 
                                                                                health=user_find['health']), reply_markup=reductadminuser)
                await FSMAdiminState1.users.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState1.description_fio)
async def fsm_description_fio(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        user_id = await state.get_data()
        await UserDataBase().get_users(user_id=user_id['user_id'], key='fio', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState1.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState1.description_age)
async def fsm_description_age(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        user_id = await state.get_data()
        await UserDataBase().get_users(user_id=user_id['user_id'], key='age', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState1.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(Text(equals=['Реалистический', 'Интеллектуальный', 'Социальный', 'Конвенциальный', 'Предприимчивый', 'Артистический']), state=FSMAdiminState1.description_test)
async def fsm_description_test(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        user_id = await state.get_data()
        match message.text:
            case 'Реалистический':
                await UserDataBase().get_users(user_id=user_id['user_id'], key='test', value='Реалистический тип (механик, электрик, инженер, фермер, зоотехник, агроном, садовод, автослесарь, шофер и т.д.)')
                await message.reply('Данные были обновлены.', reply_markup=reducts_kb)

            case 'Интеллектуальный':
                await UserDataBase().get_users(user_id=user_id['user_id'], key='test', value='Интеллектуальный тип (физик, астроном, ботаник, программист и др.)')
                await message.reply('Данные были обновлены.', reply_markup=reducts_kb)

            case 'Социальный':
                await UserDataBase().get_users(user_id=user_id['user_id'], key='test', value='Социальный тип (врач, педагог, психолог и т.п.)')
                await message.reply('Данные были обновлены.', reply_markup=reducts_kb)

            case 'Конвенциальный':
                await UserDataBase().get_users(user_id=user_id['user_id'], key='test', value='Конвенциальный тип (бухгалтер, финансист, экономист, канцелярский служащий и др)')
                await message.reply('Данные были обновлены.', reply_markup=reducts_kb)

            case 'Предприимчивый':
                await UserDataBase().get_users(user_id=user_id['user_id'], key='test', value='Предприимчивый тип (бизнесмен, маркетолог, менеджер, директор, заведующий, журналист, репортер, дипломат, юрист, политик и т.д.)')
                await message.reply('Данные были обновлены.', reply_markup=reducts_kb)

            case 'Артистический':
                await UserDataBase().get_users(user_id=user_id['user_id'], key='test', value='Артистический тип (музыкант, художник, фотограф, актер, режиссер, дизайнер и т.д.)')
                await message.reply('Данные были обновлены.', reply_markup=reducts_kb)

        await FSMAdiminState1.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])

@dp.message_handler(state=FSMAdiminState1.description_health)
async def fsm_description_health(message: Message, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=message.from_user.id)
    if stats:
        user_id = await state.get_data()
        await UserDataBase().get_users(user_id=user_id['user_id'], key='health', value=message.text)
        await message.reply('Данные были обновлены.')
        await FSMAdiminState1.reduct.set()
    elif stats is None:
        await message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await message.answer(reads()['errors']['global_error'])


@dp.callback_query_handler(text='Удалить', state=FSMAdiminState1.users)
async def redacts_dell(call: CallbackQuery, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=call.message.chat.id)
    if stats:
        user_id = await state.get_data()
        await call.answer(f'Удаление пользователя из базы по ID {user_id["user_id"]}', cache_time=60)
        stats_del = await UserDataBase().del_users(user_id=user_id["user_id"])
        if stats_del is None:
            await call.message.answer('Пользователя нет в базе...')
        else:
            await call.message.answer(f'Пользователь под ID {user_id["user_id"]} удалён из системы!', reply_markup=start_admin_kb)
    elif stats is None:
        await call.message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await call.message.answer(reads()['errors']['global_error'])

@dp.callback_query_handler(text='Выход', state=[FSMAdiminState1.users, FSMAdiminState.colleges_id])
async def redacts_exit(call: CallbackQuery, state: FSMContext):
    stats = await AdminDataBase().find_admins(admin_id=call.message.chat.id)
    if stats:
        await call.answer('Выход', cache_time=60)
        await call.message.answer('Переход в главную панель администратора', reply_markup=start_admin_kb)
        await state.finish()
    elif stats is None:
        await call.message.answer('Увы, но вас нет в системе с правами Администратор!')
    else:
        await call.message.answer(reads()['errors']['global_error'])