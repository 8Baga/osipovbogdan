import random

def random_id():
    rand_id = random.randint(1, 999999999999999)
    return rand_id


