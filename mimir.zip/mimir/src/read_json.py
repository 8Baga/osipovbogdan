import json

def reads():
    with open('./conf/text_iteral.json', 'r', encoding='UTF-8') as file:
        templates: str = json.load(file)
    return templates