from .connection import ConnectionDataBase
from datetime import datetime

class UserDataBase(ConnectionDataBase):
    
    def __init__(self):
        super().__init__('users')

    def __check_users(self, user_id: int) -> str | None:
        check = self.collection.find_one({'_id': user_id})
        if check:
            return check
        return None
    
    async def find_users(self, user_id: int) -> str | None:
        result_check = self.__check_users(user_id=user_id)
        if result_check is not None:
            return result_check
        return None
    
    async def set_users(self, user_id: int, user_nick: str, role: str = 'user', fio: str = 'Не указано', age: str = 'Не указано', test: str = 'Не указано', health: str = 'Не указано') -> bool:
        time_regist = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        result_check = self.__check_users(user_id=user_id)
        if result_check is None:
            self.collection.insert_one({
                '_id': user_id,
                "user_nick": user_nick,
                "time_regist": time_regist,
                "fio": fio,
                "age": age,
                "test": test,
                "health": health,
                "ban": False,
                "role": role,      
            })
            print(f'{user_id} был добавлен в базу данных.')
            return True
        return None
    
    async def del_users(self, user_id: int) -> bool:
        result_check = self.__check_users(user_id=user_id)
        if result_check is None:
            return None
        self.collection.delete_one({'_id': user_id})
        return True
    
    async def get_users(self, user_id: int, key, value):
        return self.collection.update_one({'_id': user_id}, {'$set': {key: value}})