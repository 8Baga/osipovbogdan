from .connection import ConnectionDataBase
from datetime import datetime

class CollegeDataBase(ConnectionDataBase):
    
    def __init__(self):
        super().__init__('colleges')

    def __check_colleges(self, college_id: int) -> str | None:
        check = self.collection.find_one({'_id': college_id})
        if check:
            return check
        return None
    
    async def find_colleges(self, college_id: int) -> str | None:
        result_check = self.__check_colleges(college_id=college_id)
        if result_check is not None:
            return result_check
        return None
    
    async def find_test_colleges(self, key, value):
        result = self.collection.find({key: value})
        return result
    
    async def set_colleges(self, college_id: int, college_name: str, description_type: str, college_speciality: str = 'В заполнении', college_health: str = 'В заполнении', klass: str = 'В заполнении', results: str = 'В заполнении', format: str = 'В заполнении', pay: str = 'В заполнении') -> bool:
        result_check = self.__check_colleges(college_id=college_id)
        if result_check is None:
            self.collection.insert_one({
                '_id': college_id,
                "college_name": college_name,
                "description_type": description_type,
                "college_speciality": college_speciality,
                "college_health": college_health,
                "klass": klass,
                "results": results,
                "format": format,
                "pay": pay,     
            })
            print(f'{college_id} был добавлен в базу данных.')
            return True
        return None
    
    async def del_colleges(self, colleges_id: int) -> bool:
        result_check = self.__check_colleges(college_id=colleges_id)
        if result_check is None:
            return None
        self.collection.delete_one({'_id': colleges_id})
        return True
    
    async def get_colleges(self, college_id: int, key, value):
        return self.collection.update_one({'_id': college_id}, {'$set': {key: value}})