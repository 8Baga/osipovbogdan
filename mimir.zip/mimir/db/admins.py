from .connection import ConnectionDataBase

class AdminDataBase(ConnectionDataBase):

    def __init__(self):
        super().__init__('admins')

    def __check_admins(self, admin_id: int) -> str | None:
        check = self.collection.find_one({'_id': admin_id})
        if check:
            return check
        return None
    
    async def find_admins(self, admin_id: int) -> str | None:
        result_check = self.__check_admins(admin_id=admin_id)
        if result_check is not None:
            return result_check
        return None

    async def set_admins(self, admin_id: int) -> bool:
        result_check = self.__check_admins(admin_id=admin_id)
        if result_check is None:
            self.collection.insert_one({
                '_id': admin_id, 
            })
            print(f'ID [{admin_id}] | Администратор был добавлен в базу данных.')
            return True
        return False

    async def get_admins(self, admin_id: int, key, value):
        return self.collection.update_one({'_id': admin_id}, {'$set': {key: value}})
    
    async def delite_admins(self, admin_id: int) -> bool:
        result_check = self.__check_admins(admin_id=admin_id)
        if result_check is not None:
            self.collection.delete_one({'_id': admin_id})
            print(f'ID [{admin_id}] | Администратор {result_check["level"]} был удалён из базы данных.')
            return True
        return False
        