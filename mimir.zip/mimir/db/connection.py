from pymongo import MongoClient

class ConnectionDataBase:

    def __init__(self, collection: str):
        db = MongoClient('mongodb://localhost:27017')['Mimir']
        self.collection = db.get_collection(f'{collection}')