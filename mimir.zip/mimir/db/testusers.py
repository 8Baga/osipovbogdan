from .connection import ConnectionDataBase

class TestDataBase(ConnectionDataBase):
    
    def __init__(self):
        super().__init__('testusers')

    def __check_testusers(self, user_id: int) -> str | None:
        check = self.collection.find_one({'_id': user_id})
        if check:
            return check
        return None
    
    async def find_testusers(self, user_id: int) -> str | None:
        result_check = self.__check_testusers(user_id=user_id)
        if result_check is not None:
            return result_check
        return None
    
    async def set_testusers(self, user_id: int) -> bool:
        result_check = self.__check_testusers(user_id=user_id)
        if result_check is None:
            self.collection.insert_one({
                '_id': user_id,
                "1": None,
                "2": None,
                "3": None,
                "4": None,
                "5": None,
                "6": None,
                "7": None,
                "8": None,
                "9": None,
                "10": None,
                "11": None,
                "12": None,
                "13": None,
                "14": None,
                "15": None,
                "16": None,
                "17": None,
                "18": None,
                "19": None,
                "20": None,
                "21": None,
            })
            return True
        return None

    async def get_testusers(self, user_id: int, key, value):
        return self.collection.update_one({'_id': user_id}, {'$set': {key: value}})